USE DR2_User_R1
GO

DECLARE @New_TownNo smallint
SET @New_TownNo = 4

INSERT [dbo].[TB_User_MyHome_Base] 
	SELECT @New_TownNo+[StreetNo]-1
		,[HouseNo]
		,[HomePrice]
		,[GroundNo]
		,[HomeInSideGuid]
		,[HomeOutSideGuid]
		,[OwnerGuid]
		,[EanbleVisitorBit]
		,[AuctionTime]
		,[AuctionState]
		,[BidderGuid]
		,[FirstBiddingCost]
		,[LastBiddingCost]
		,[PayTexTime]
		,[PayTexNotiTime]
		,[HomeColor]
		,[HomeStyle]
		,[HomeFence]
		,[HomeGarden]
		,[TodayDay]
		,[ToDayHitCount]
		,[TotalHitCount]
		,[RoomWall]
		,[RoomFloor]
		,[AuctionLvLimitMin]
		,[AuctionLvLimitMax]
		FROM [DR2_User_R2].[dbo].[TB_User_MyHome_Base]
GO

INSERT [dbo].[TB_User_MyHome_EquipItem] SELECT * FROM [DR2_User_R2].[dbo].[TB_User_MyHome_EquipItem]
GO

DECLARE @New_TownNo smallint
SET @New_TownNo = 4

INSERT [dbo].[TB_User_MyHome_Invitation]
	SELECT [CardGuid]
		,[OwnerGuid]
		,@New_TownNo+[StreetNo]-1
		,[HouseNo]
		,[LimitTime]
		,[GenYear]
		,[GenMon]
		,[GenDay]
		,[Used]
		FROM [DR2_User_R2].[dbo].[TB_User_MyHome_Invitation]
GO

DECLARE @New_TownNo smallint
SET @New_TownNo = 4

INSERT [dbo].[TB_User_MyHome_TodayVisitors]
	SELECT @New_TownNo+[TownNo]-1
		,[HouseNo]
		,[VisitorGuid]
		,[VisitDay]
		FROM [DR2_User_R2].[dbo].[TB_User_MyHome_TodayVisitors]
GO

INSERT [dbo].[TB_User_MyHome_VisitLog] SELECT * FROM [DR2_User_R2].[dbo].[TB_User_MyHome_VisitLog]
GO

DECLARE @New_TownNo smallint
SET @New_TownNo = 4

INSERT [dbo].[TB_User_MyHome_Visitors]
	SELECT @New_TownNo+[StreetNo]-1
		,[HouseNo]
		,[VisitorGuid]
		,[VisitTime]
		FROM [DR2_User].[dbo].[TB_User_MyHome_Visitors]
GO