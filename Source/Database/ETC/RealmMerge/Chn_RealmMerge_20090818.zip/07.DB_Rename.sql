


/********************************4.Change DB Name START*********************************/
USE master
GO

--���� DR2_User�� DR2_User_R1_Origin
EXEC sp_dboption DR2_User,'single USER','ON'  
GO
EXEC sp_renamedb 'DR2_User','DR2_User_R1_Origin'
GO
EXEC sp_dboption DR2_User_R1_Origin,'single USER','FALSE' 
GO

--DR2_User_R1�� DR2_User
EXEC sp_dboption DR2_User_R1,'single USER','ON'  
GO
EXEC sp_renamedb 'DR2_User_R1','DR2_User'
GO
EXEC sp_dboption DR2_User,'single USER','FALSE' 
GO
/********************************4.Change DB Name END*********************************/