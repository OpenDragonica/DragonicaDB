
/********************************3.������ ������ ���� ����*********************************/
USE DR2_User_R1
GO

--step1.TRUNCATE TABLE

	/*
	-- R1 Emporia �� �״�� ���� �Ѵ�.
	TRUNCATE TABLE [dbo].[TB_Guild_Emporia]
	TRUNCATE TABLE [dbo].[TB_Guild_Emporia_Function]
	TRUNCATE TABLE [dbo].[TB_Guild_Emporia_ReserveBattle]
	TRUNCATE TABLE [dbo].[TB_Guild_EmporiaFunction]
	*/
	/*
	-- CHN ���̺� �̸� �ٸ�
	TRUNCATE TABLE dbo.TB_Guild_Emporia
	TRUNCATE TABLE dbo.TB_Emporia_ChallengeBattle
	TRUNCATE TABLE dbo.TB_Emporia_Function
	TRUNCATE TABLE dbo.TB_Emporia_Tournament
	TRUNCATE TABLE dbo.TB_EmporiaPack
	*/
	
GO

--step2.INSERT SELECT
--dbo.TB_UserMail - MailIndex - IDENTITY
INSERT dbo.TB_UserMail(MailGuid, FromGuid, ToGuid, Title, Note, PaymentType, ItemGuid, Money, SendTime, LimitTime, ReadBit, ReturnBit, AnnexBit, PaymentBit)  
SELECT MailGuid, FromGuid, ToGuid, Title, Note, PaymentType, ItemGuid, Money, SendTime, LimitTime, ReadBit, ReturnBit, AnnexBit, PaymentBit
FROM DR2_User_R2.dbo.TB_UserMail
GO


--dbo.TB_Mission_Rank Idx - IDENTITY
INSERT dbo.TB_Mission_Rank([Group], MissionKey, Level, CharacterID, Memo, UserLevel, Class, Point, PlayTime, Date)
SELECT [Group], MissionKey, Level, CharacterID, Memo, UserLevel, Class, Point, PlayTime, Date FROM DR2_User_R2.dbo.TB_Mission_Rank
GO

-- �׳� ��ġ�� �Ǵ°�
/*
-- CHN�� ���� ���̺�
INSERT dbo.TB_LimitedItemRecord(EventNo, Memo, LimitRefreshDate, SafeRefreshDate, StartDate, EndDate, Limit_ResetPeriod, Safe_ResetPeriod, RefreshCount, LimitCount, SafeCount) SELECT EventNo, Memo, LimitRefreshDate, SafeRefreshDate, StartDate, EndDate, Limit_ResetPeriod, Safe_ResetPeriod, RefreshCount, LimitCount, SafeCount FROM DR2_User_R2.dbo.TB_LimitedItemRecord
GO
INSERT dbo.TB_Pet SELECT * FROM DR2_User_R2.dbo.TB_Pet
*/
INSERT dbo.TB_ExpCard SELECT * FROM DR2_User_R2.dbo.TB_ExpCard
INSERT dbo.TB_UserCash_Rank SELECT * FROM DR2_User_R2.dbo.TB_UserCash_Rank
INSERT dbo.TB_UserCharacter_Card SELECT * FROM DR2_User_R2.dbo.TB_UserCharacter_Card
INSERT dbo.TB_UserItem_UnbindDate SELECT * FROM DR2_User_R2.dbo.TB_UserItem_UnbindDate
INSERT dbo.TB_UserPortal SELECT * FROM DR2_User_R2.dbo.TB_UserPortal
INSERT dbo.TB_UserCouple SELECT * FROM DR2_User_R2.dbo.TB_UserCouple
INSERT dbo.TB_Penalty SELECT * FROM DR2_User_R2.dbo.TB_Penalty
GO
INSERT dbo.TB_Guild_Extern_Info SELECT * FROM DR2_User_R2.dbo.TB_Guild_Extern_Info	--621
GO
INSERT dbo.TB_Guild_Member_Grade SELECT * FROM DR2_User_R2.dbo.TB_Guild_Member_Grade	--621
GO
INSERT dbo.TB_UserCash_Rank SELECT * FROM DR2_User_R2.dbo.TB_UserCash_Rank	--1958
GO
INSERT dbo.TB_UserCashGift SELECT * FROM DR2_User_R2.dbo.TB_UserCashGift	--3625
GO
INSERT dbo.TB_UserDealings SELECT * FROM DR2_User_R2.dbo.TB_UserDealings	--4928
GO
INSERT dbo.TB_UserMarketInfo2 SELECT * FROM DR2_User_R2.dbo.TB_UserMarketInfo2	--7857
GO
INSERT dbo.TB_UserMarket SELECT * FROM DR2_User_R2.dbo.TB_UserMarket	--13546
GO

-- CHN���� �ִ� ���̺�
INSERT dbo.TB_UserItem_Message SELECT * FROM DR2_User_R2.dbo.TB_UserItem_Message
GO
INSERT dbo.TB_UserMailIndex SELECT * FROM DR2_User_R2.dbo.TB_UserMailIndex
GO
INSERT dbo.TB_UserMarketInfo SELECT * FROM DR2_User_R2.dbo.TB_UserMarketInfo
GO


--4:46	(42084�� �� �����)
INSERT dbo.TB_UserCharacter_Extern SELECT * FROM DR2_User_R2.dbo.TB_UserCharacter_Extern	
GO

--(42084�� �� �����)
INSERT dbo.TB_UserCharacter_Point SELECT * FROM DR2_User_R2.dbo.TB_UserCharacter_Point	
GO

--28�� (92259�� �� �����)
INSERT dbo.TB_UserFriend SELECT * FROM DR2_User_R2.dbo.TB_UserFriend	
GO

----------------TB_Record_LevelUp_PlayTimeSec ���̺� ó��
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TB_Record_LevelUp_PlayTimeSec]') AND name = N'IX_C_TB_Record_LevelUp_PlayTimeSec_CharacterID_LEVEL')
	DROP INDEX [IX_C_TB_Record_LevelUp_PlayTimeSec_CharacterID_LEVEL] ON [dbo].[TB_Record_LevelUp_PlayTimeSec] WITH ( ONLINE = OFF )
GO
--(379664�� �� �����)
INSERT dbo.TB_Record_LevelUp_PlayTimeSec SELECT * FROM DR2_User_R2.dbo.TB_Record_LevelUp_PlayTimeSec	
GO

--7��
CREATE NONCLUSTERED INDEX [IX_C_TB_Record_LevelUp_PlayTimeSec_CharacterID_LEVEL] ON [dbo].[TB_Record_LevelUp_PlayTimeSec] 
(
	[CharacterID] ASC,
	[Level] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON, FILLFACTOR = 80) ON [PRIMARY]
GO
----------------TB_Record_LevelUp_PlayTimeSec ���̺� ó��


----------------TB_UserAchievements ���̺� ó��
--PK ����
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TB_UserAchievements]') AND name = N'PK_TB_UserAchievements_CharGuId_Type')
	ALTER TABLE [dbo].[TB_UserAchievements] DROP CONSTRAINT [PK_TB_UserAchievements_CharGuId_Type]
GO
--���� (409801�� �� �����)
INSERT dbo.TB_UserAchievements SELECT * FROM DR2_User_R2.dbo.TB_UserAchievements	
GO
--PK ����	--8��
ALTER TABLE [dbo].[TB_UserAchievements] ADD  CONSTRAINT [PK_TB_UserAchievements_CharGuId_Type] PRIMARY KEY CLUSTERED 
(
	[CharGuId] ASC,
	[Type] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON, FILLFACTOR = 80) ON [PRIMARY]
----------------TB_UserAchievements ���̺� ó��


----------------TB_UserItem ���̺� ó��
--PK ����
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TB_UserItem]') AND name = N'PK_TB_UserItem_ItemGuid')
	ALTER TABLE [dbo].[TB_UserItem] DROP CONSTRAINT [PK_TB_UserItem_ItemGuid]
GO
--INDEX ����	-43��
DROP INDEX TB_UserItem.IX_C_TB_UserItem_OwnerGuid
GO
DROP INDEX TB_UserItem.IX_NC_TB_UserItem_ItemNO
GO
--(1273048�� �� �����) 1:49
INSERT dbo.TB_UserItem SELECT * FROM DR2_User_R2.dbo.TB_UserItem		
GO
--PK ����	
ALTER TABLE [dbo].[TB_UserItem] ADD  CONSTRAINT [PK_TB_UserItem_ItemGuid] PRIMARY KEY NONCLUSTERED 
(
	[ItemGuid] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON, FILLFACTOR = 80) ON [PRIMARY]
--INDEX ���� 1:57
CREATE CLUSTERED INDEX IX_C_TB_UserItem_OwnerGuid	ON TB_UserItem(OwnerGuid)
GO
CREATE INDEX IX_NC_TB_UserItem_ItemNO	ON TB_UserItem(ItemNo)
GO

/*
-- CHN�� ���� ���̺�
INSERT dbo.TB_UserItem_Enchant SELECT * FROM DR2_User_R2.dbo.TB_UserItem_Enchant
*/
GO

----------------TB_UserItem ���̺� ó��




/********************************3.������ ������ ���� ����*********************************/