USE DR2_Member_1
GO

-- S1 Copy
SELECT * INTO [DR2_Member_1].[dbo].[Member_Dst] FROM [DR2_Member_1].[dbo].[Member]
	WHERE [ID] not in (SELECT [ID] FROM [DR2_Member_2].[dbo].[Member])
GO

SELECT * INTO [DR2_Member_1].[dbo].[TB_MemberSub_Dst] FROM [DR2_Member_1].[dbo].[TB_MemberSub]
GO

-- S2 Copy
SELECT [MemberKey] INTO [DR2_Member_1].[dbo].[Member_OnlyS2] FROM [DR2_Member_2].[dbo].[Member]
	WHERE [ID] not in (SELECT [ID] FROM [DR2_Member_1].[dbo].[Member])
GO

INSERT INTO [DR2_Member_1].[dbo].[Member_Dst]
	SELECT * FROM [DR2_Member_2].[dbo].[Member]
		WHERE [ID] not in (SELECT [ID] FROM [DR2_Member_1].[dbo].[Member])
GO

INSERT INTO [DR2_Member_1].[dbo].[TB_MemberSub_Dst]
	SELECT * FROM [DR2_Member_1].[dbo].[TB_MemberSub]
		WHERE [MemberKey] in (SELECT [MemberKey] FROM [DR2_Member_1].[dbo].[Member_OnlyS2])
GO

-- Backup Duplicated ID (S2)
SELECT S1.[ID] AS [ID], S1.[MemberKey] AS [S1_Key], S2.[MemberKey] AS [S2_Key] INTO [DR2_Member_1].[dbo].[Member_Dupl]
	FROM [DR2_Member_1].[dbo].[Member] AS S1
	LEFT JOIN [DR2_Member_2].[dbo].[Member] AS S2 ON S1.[ID] = S2.[ID]
GO

-- TB_Member_Sub �� �ߺ��Ǹ� S1 �� ���


INSERT INTO [DR2_Member_1].[dbo].[Member_Dst]
           ([UID]
           ,[MemberKey]
           ,[ID]
           ,[PW]
           ,[Gender]
           ,[CreateDate]
           ,[GMLevel]
           ,[Block]
           ,[Cash]
           ,[TotalConnectTime]
           ,[AccDisconnectTime]
           ,[AccConnectTime]
           ,[LastLoginDate]
           ,[LastLogoutDate]
           ,[BirthDay]
           ,[BlockStartTime]
           ,[BlockEndTime]
           ,[ConnectionChannel]
           ,[ConnectionRealm]
           ,[GMComment]
           ,[BonusCash]
           ,[EventKey]
           ,[EventRewardKey])

-- Copy Duplicated ID
INSERT INTO [DR2_Member_1].[dbo].[Member_Dst]
	([UID],[MemberKey],[ID],[PW],[Gender]
	,[CreateDate],[GMLevel],[Block],[Cash],[TotalConnectTime]
	,[AccDisconnectTime],[AccConnectTime],[LastLoginDate],[LastLogoutDate],[BirthDay]
	,[BlockStartTime],[BlockEndTime],[ConnectionChannel],[ConnectionRealm],[GMComment]
	,[BonusCash],[EventKey],[EventRewardKey])
	SELECT S1.UID,
		S1.MemberKey,
		S1.ID,
		S1.PW,
		S1.Gender,
		S1.CreateDate,
		CASE WHEN S1.GMLevel > S2.GMLevel THEN S2.GMLevel ELSE S1.GMLevel END,	-- ������ ���
		CASE WHEN S1.Block > 0 THEN S1.Block ELSE S2.Block END,	-- S1�� �켱
		S1.Cash + S2.Cash,
		S1.TotalConnectTime + S2.TotalConnectTime,
		0,	-- AccDisconnectTime
		0,	-- AccConnectTime
		CASE WHEN S1.LastLoginDate > S2.LastLoginDate THEN S1.LastLoginDate ELSE S2.LastLoginDate END,
		CASE WHEN S1.LastLogoutDate > S2.LastLogoutDate THEN S1.LastLogoutDate ELSE S2.LastLogoutDate END,
		CASE WHEN S1.BirthDay > S2.BirthDay THEN S1.BirthDay ELSE S2.BirthDay END,
		CASE WHEN S1.Block > 0 THEN S1.BlockStartTime ELSE S2.BlockStartTime END,
		CASE WHEN S1.Block > 0 THEN S1.BlockEndTime ELSE S2.BlockEndTime END,
		0,	-- ConnectionChannel
		0,	-- ConnectionRealm
		S1.GMComment,
		S1.BonusCash + S2.BonusCash,
		S1.EventKey,
		S1.EventRewardKey
		FROM [DR2_Member_1].[dbo].[Member] AS S1
			LEFT JOIN [DR2_Member_2].[dbo].[Member] AS S2 ON S1.[ID] = S2.[ID]
GO

TRUNCATE TABLE [DR2_Member_1].[dbo].[TB_AdminCmd]
GO

-- No change
/*
	TB_DefGMAccountLinkIP
	TB_DefPlayerPlayTime
	TB_DefPlayerPlayTimeSub
	-- EVENT
	TB_Event_Reward
	TB_Event_Type
	TB_Event_Type_Reward
	-- EVENT QUEST
	TB_EventQuest
	TB_EventQuest_CompleteStatus
	TB_EventQuest_Notice
	TB_EventQuest_Reward
	TB_EventQuest_Status
	TB_EventQuest_Target
	tbl_CashType
*/

-- TB_Event_Coupon
INSERT INTO [DR2_Member_1].[dbo].[TB_Event_Coupon]
	([f_CouponID],[f_EventKey],[f_RewardKey],[f_OwnerMemberGuid],[f_OwnerCharacterGuid]
	,[f_TakerMemberGuid],[f_TakerCharacterGuid],[f_CreateDate],[f_TakeDate],[f_RewardGuid1]
	,[f_RewardGuid2],[f_RewardGuid3],[f_RewardGuid4],[f_Site],[f_Realm])
   	SELECT [f_CouponID],[f_EventKey],[f_RewardKey],[f_OwnerMemberGuid],[f_OwnerCharacterGuid]
		,[f_TakerMemberGuid],[f_TakerCharacterGuid],[f_CreateDate],[f_TakeDate],[f_RewardGuid1]
		,[f_RewardGuid2],[f_RewardGuid3],[f_RewardGuid4],[f_Site],[f_Realm]
		FROM [DR2_Member_2].[dbo].[TB_Event_Coupon]
		WHERE [f_CouponID] not in (SELECT [f_CouponID] FROM [DR2_Member_1].[dbo].[TB_Event_Coupon])
GO
-- TB_Event_Coupon : MemberKey update
UPDATE [DR2_Member_1].[dbo].[TB_Event_Coupon] SET [f_OwnerMemberGuid] = B.[S1_Key]
	FROM [DR2_Member_1].[dbo].[TB_Event_Coupon] AS A
	RIGHT JOIN [DR2_Member_1].[dbo].[Member_Dupl] AS B ON A.[f_OwnerMemberGuid] = B.[S2_Key]
GO
UPDATE [DR2_Member_1].[dbo].[TB_Event_Coupon] SET [f_TakerMemberGuid] = B.[S1_Key]
	FROM [DR2_Member_1].[dbo].[TB_Event_Coupon] AS A
	RIGHT JOIN [DR2_Member_1].[dbo].[Member_Dupl] AS B ON A.[f_TakerMemberGuid] = B.[S2_Key]
GO

-- Tbl_CashLog : Backup S2
SELECT * INTO [DR2_Member_1].[dbo].[Tbl_CashLog_Cpy] FROM [DR2_Member_2].[dbo].[tbl_CashLog]
GO
-- UPDATE duplicated Member key
UPDATE [DR2_Member_1].[dbo].[Tbl_CashLog_Cpy] SET MemberKey = B.[S1_Key]
	FROM [DR2_Member_1].[dbo].[Tbl_CashLog_Cpy] AS A
	RIGHT JOIN [DR2_Member_1].[dbo].[Member_Dupl] AS B ON A.[MemberKey] = B.[S2_Key]
GO

INSERT INTO [DR2_Member_1].[dbo].[Tbl_CashLog]
	([MemberKey],[CharacterID],[f_type],[f_status],[f_amount]
	,[f_current],[f_date],[f_memo],[f_usedmileage],[f_newmileage]
	,[f_curmileage],[f_CashCode])
	SELECT [MemberKey],[CharacterID],[f_type],[f_status],[f_amount]
		,[f_current],[f_date],[f_memo],[f_usedmileage],[f_newmileage]
		,[f_curmileage],[f_CashCode]
		FROM [DR2_Member_1].[dbo].[Tbl_CashLog_Cpy] 
GO


-- Member Data result : Member_Dst -> Member
TRUNCATE TABLE [DR2_Member_1].[dbo].[Member]
GO
INSERT INTO [DR2_Member_1].[dbo].[Member]
	SELECT * FROM [DR2_Member_1].[dbo].[Member_Dst]
GO
-- Member Data result : TB_MemberSub_Dst -> TB_MemberSub
TRUNCATE TABLE [DR2_Member_1].[dbo].[TB_MemberSub]
GO
INSERT INTO [DR2_Member_1].[dbo].[TB_MemberSub]
	SELECT * FROM [DR2_Member_1].[dbo].[TB_MemberSub_Dst]
GO
