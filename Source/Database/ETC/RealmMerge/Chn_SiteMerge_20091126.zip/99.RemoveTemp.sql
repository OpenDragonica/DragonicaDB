USE DR2_Member_1
GO

DROP TABLE [DR2_Member_1].[dbo].[Member_Dst]
GO
DROP TABLE [DR2_Member_1].[dbo].[TB_MemberSub_Dst]
GO
DROP TABLE [DR2_Member_1].[dbo].[Tbl_CashLog_Cpy] 
GO
DROP TABLE [DR2_Member_1].[dbo].[Member_Dupl]
GO
DROP TABLE [DR2_Member_1].[dbo].[Member_OnlyS2]
GO
