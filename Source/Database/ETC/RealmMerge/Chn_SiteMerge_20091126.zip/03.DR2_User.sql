USE DR2_User_2
GO

-- TB_CharacterBasic
UPDATE [DR2_User_2].[dbo].[TB_CharacterBasic] SET MemberID = B.[S1_Key]
	FROM [DR2_User_2].[dbo].[TB_CharacterBasic] AS A
	RIGHT JOIN [DR2_Member_1].[dbo].[Member_Dupl] AS B ON A.[MemberID] = B.[S2_Key]
GO
