USE DR2_Member_S1
GO

-- Checking duplicated Account ID
SELECT A.[ID] AS A_ID, A.[Cash] AS A_CASH, A.[MemberKey] AS A_MK, B.[ID] AS B_ID, B.[Cash] AS B_CASH , B.[MemberKey] AS B_MK
	FROM [DR2_Member_S1].[dbo].[Member] AS A
	INNER JOIN [DR2_Member_S2].[dbo].[Member] AS B ON A.[ID] = B.[ID]

-- Checking duplicated Member key
SELECT A.[ID] AS A_ID, A.[Cash] AS A_CASH, A.[MemberKey] AS A_MK, B.[ID] AS B_ID, B.[Cash] AS B_CASH , B.[MemberKey] AS B_MK
	FROM [DR2_Member_S1].[dbo].[Member] AS A
	INNER JOIN [DR2_Member_S2].[dbo].[Member] AS B ON A.[MemberKey] = B.[MemberKey]
