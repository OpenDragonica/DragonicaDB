

-- Check Emporia Challenger
USE DR2_User_R1
GO
SELECT B.* FROM [dbo].[TB_EmporiaPack] AS A
	LEFT JOIN [dbo].[TB_Emporia_ChallengeBattle] AS B ON A.[BattleID] = B.[BattleID]
	WHERE B.[State] < 100	-- [STATE]>100 �ΰ��� Emporia battle

USE DR2_User_R2
GO
SELECT B.* FROM [dbo].[TB_EmporiaPack] AS A
	LEFT JOIN [dbo].[TB_Emporia_ChallengeBattle] AS B ON A.[BattleID] = B.[BattleID]
	WHERE B.[State] < 100	-- [STATE]>100 �ΰ��� Emporia battle
