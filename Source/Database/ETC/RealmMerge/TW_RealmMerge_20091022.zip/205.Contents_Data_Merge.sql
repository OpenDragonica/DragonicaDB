
/********************************3.������ ������ ���� ����*********************************/
USE DR2_User_R1
GO


/*	/////////////////////////////////////////////////////////
 	STEP 1. 
///////////////////////////////////////////////////////// */
-- Emporia ���� backup
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup_TB_Emporia]') AND type in (N'U'))
	DROP TABLE [dbo].[Backup_TB_Emporia]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup_TB_Emporia_ChallengeBattle]') AND type in (N'U'))
	DROP TABLE [dbo].[Backup_TB_Emporia_ChallengeBattle]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup_TB_Emporia_Function]') AND type in (N'U'))
	DROP TABLE [dbo].[Backup_TB_Emporia_Function]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup_TB_Emporia_Tournament]') AND type in (N'U'))
	DROP TABLE [dbo].[Backup_TB_Emporia_Tournament]
GO

SELECT * INTO [dbo].[Backup_TB_Emporia] FROM [dbo].[TB_Emporia]
SELECT * INTO [dbo].[Backup_TB_Emporia_ChallengeBattle] FROM [dbo].[TB_Emporia_ChallengeBattle]
SELECT * INTO [dbo].[Backup_TB_Emporia_Function] FROM [dbo].[TB_Emporia_Function]
SELECT * INTO [dbo].[Backup_TB_Emporia_Tournament] FROM [dbo].[TB_Emporia_Tournament]

TRUNCATE TABLE [dbo].[TB_Emporia]
TRUNCATE TABLE [dbo].[TB_Emporia_ChallengeBattle]
TRUNCATE TABLE [dbo].[TB_Emporia_Function]
TRUNCATE TABLE [dbo].[TB_Emporia_Tournament]

/*	/////////////////////////////////////////////////////////
 	STEP 2. 
///////////////////////////////////////////////////////// */
--step2.INSERT SELECT
--dbo.TB_UserMail - MailIndex - IDENTITY
INSERT dbo.TB_UserMail(MailGuid, FromGuid, ToGuid, Title, Note, PaymentType, ItemGuid, Money, SendTime, LimitTime, ReadBit, ReturnBit, AnnexBit, PaymentBit)  
SELECT MailGuid, FromGuid, ToGuid, Title, Note, PaymentType, ItemGuid, Money, SendTime, LimitTime, ReadBit, ReturnBit, AnnexBit, PaymentBit
FROM DR2_User_R2.dbo.TB_UserMail
GO

/*	/////////////////////////////////////////////////////////
 	STEP 3. 
///////////////////////////////////////////////////////// */
--dbo.TB_Mission_Rank Idx - IDENTITY
INSERT dbo.TB_Mission_Rank([Group], MissionKey, Level, CharacterID, Memo, UserLevel, Class, Point, PlayTime, Date)
SELECT [Group], MissionKey, Level, CharacterID, Memo, UserLevel, Class, Point, PlayTime, Date FROM DR2_User_R2.dbo.TB_Mission_Rank
GO

/*
--		��ġ�� �ȵǴ� ���̺�
INSERT dbo.TB_LimitedItemRecord SELECT * FROM DR2_User_R2.dbo.TB_LimitedItemRecord
GO

INSERT dbo.TB_DefBaseUserItem SELECT * FROM DR2_User_R2.dbo.TB_DefBaseUserItem
GO

INSERT dbo.TB_Mission_Report SELECT * FROM DR2_User_R2.dbo.TB_Mission_Report
GO

INSERT dbo.TB_OXQuizEventState SELECT * FROM DR2_User_R2.dbo.TB_OXQuizEventState
GO

INSERT dbo.TB_EVENT SELECT * FROM DR2_User_R2.dbo.TB_EVENT
GO

*/
/*
-- Ȯ���� �ʿ��� ���̺�
*/
/*
-- ��� ���ϴ� ���̺�
INSERT dbo.TB_UserItem_Message SELECT * FROM DR2_User_R2.dbo.TB_UserItem_Message
GO
INSERT dbo.TB_UserCharacter SELECT * FROM DR2_User_R2.dbo.TB_UserCharacter
GO
INSERT dbo.TB_Member_ShareData SELECT * FROM DR2_User_R2.dbo.TB_Member_ShareData
GO
*/

/*	/////////////////////////////////////////////////////////
 	STEP 4. 
///////////////////////////////////////////////////////// */
INSERT dbo.TB_ExpCard SELECT * FROM DR2_User_R2.dbo.TB_ExpCard
GO
INSERT dbo.TB_UserCash_Rank SELECT * FROM DR2_User_R2.dbo.TB_UserCash_Rank
GO
INSERT dbo.TB_UserCharacter_Card SELECT * FROM DR2_User_R2.dbo.TB_UserCharacter_Card
GO
INSERT dbo.TB_UserPortal SELECT * FROM DR2_User_R2.dbo.TB_UserPortal
GO
INSERT dbo.TB_UserCouple SELECT * FROM DR2_User_R2.dbo.TB_UserCouple
GO
INSERT dbo.TB_Penalty SELECT * FROM DR2_User_R2.dbo.TB_Penalty
GO
INSERT dbo.TB_Guild_Extern_Info SELECT * FROM DR2_User_R2.dbo.TB_Guild_Extern_Info	--621
GO
INSERT dbo.TB_Guild_Member_Grade SELECT * FROM DR2_User_R2.dbo.TB_Guild_Member_Grade	--621
GO
INSERT dbo.TB_UserCashGift SELECT * FROM DR2_User_R2.dbo.TB_UserCashGift	--3625
GO
INSERT dbo.TB_UserDealings SELECT * FROM DR2_User_R2.dbo.TB_UserDealings	--4928
GO
INSERT dbo.TB_UserMarketInfo2 SELECT * FROM DR2_User_R2.dbo.TB_UserMarketInfo2	--7857
GO
INSERT dbo.TB_UserMarket SELECT * FROM DR2_User_R2.dbo.TB_UserMarket	--13546
GO
INSERT dbo.TB_UserCharacter_Extern SELECT * FROM DR2_User_R2.dbo.TB_UserCharacter_Extern	
GO
INSERT dbo.TB_UserCharacter_Point SELECT * FROM DR2_User_R2.dbo.TB_UserCharacter_Point	
GO
INSERT dbo.TB_UserFriend SELECT * FROM DR2_User_R2.dbo.TB_UserFriend	
GO
INSERT dbo.TB_Pet SELECT * FROM DR2_User_R2.dbo.TB_Pet
GO


/*	/////////////////////////////////////////////////////////
 	STEP 5. 
///////////////////////////////////////////////////////// */
----------------TB_Record_LevelUp_PlayTimeSec ���̺� ó��
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TB_Record_LevelUp_PlayTimeSec]') AND name = N'IX_C_TB_Record_LevelUp_PlayTimeSec_CharacterID_LEVEL')
	DROP INDEX [IX_C_TB_Record_LevelUp_PlayTimeSec_CharacterID_LEVEL] ON [dbo].[TB_Record_LevelUp_PlayTimeSec] WITH ( ONLINE = OFF )
GO
--(379664�� �� �����)
INSERT dbo.TB_Record_LevelUp_PlayTimeSec SELECT * FROM DR2_User_R2.dbo.TB_Record_LevelUp_PlayTimeSec	
GO

--7��
CREATE NONCLUSTERED INDEX [IX_C_TB_Record_LevelUp_PlayTimeSec_CharacterID_LEVEL] ON [dbo].[TB_Record_LevelUp_PlayTimeSec] 
(
	[CharacterID] ASC,
	[Level] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON, FILLFACTOR = 80) ON [PRIMARY]
GO
----------------TB_Record_LevelUp_PlayTimeSec ���̺� ó��


/*	/////////////////////////////////////////////////////////
 	STEP 6. 
///////////////////////////////////////////////////////// */
----------------TB_UserAchievements ���̺� ó��
--PK ���� ( CHECKPOINT : PK �̸� Ȯ��)
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TB_UserAchievements]') AND name = N'PK_TB_UserAchievements_CharGuId_Type')
	ALTER TABLE [dbo].[TB_UserAchievements] DROP CONSTRAINT [PK_TB_UserAchievements_CharGuId_Type]
GO
--���� (409801�� �� �����)
INSERT dbo.TB_UserAchievements SELECT * FROM DR2_User_R2.dbo.TB_UserAchievements	
GO
--PK ����	--8��
ALTER TABLE [dbo].[TB_UserAchievements] ADD  CONSTRAINT [PK_TB_UserAchievements_CharGuId_Type] PRIMARY KEY CLUSTERED 
(
	[CharGuId] ASC,
	[Type] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON, FILLFACTOR = 80) ON [PRIMARY]
----------------TB_UserAchievements ���̺� ó��


/*	/////////////////////////////////////////////////////////
 	STEP 7. 
///////////////////////////////////////////////////////// */
----------------TB_UserItem ���̺� ó��
--PK ���� ( CHECKPOINT : PK �̸� Ȯ��)
IF  EXISTS (SELECT * FROM sys.indexes WHERE object_id = OBJECT_ID(N'[dbo].[TB_UserItem]') AND name = N'PK_TB_UserItem_ItemGuid')
	ALTER TABLE [dbo].[TB_UserItem] DROP CONSTRAINT [PK_TB_UserItem_ItemGuid]
GO
--INDEX ����	-43��
DROP INDEX TB_UserItem.IX_C_TB_UserItem_OwnerGuid
GO
DROP INDEX TB_UserItem.IX_NC_TB_UserItem_ItemNO
GO
--(1273048�� �� �����) 1:49
INSERT dbo.TB_UserItem SELECT * FROM DR2_User_R2.dbo.TB_UserItem		
GO
--PK ����	
ALTER TABLE [dbo].[TB_UserItem] ADD  CONSTRAINT [PK_TB_UserItem_ItemGuid] PRIMARY KEY NONCLUSTERED 
(
	[ItemGuid] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON, FILLFACTOR = 80) ON [PRIMARY]
--INDEX ���� 1:57
CREATE CLUSTERED INDEX IX_C_TB_UserItem_OwnerGuid	ON TB_UserItem(OwnerGuid)
GO
CREATE INDEX IX_NC_TB_UserItem_ItemNO	ON TB_UserItem(ItemNo)
GO

INSERT dbo.TB_UserItem_Enchant SELECT * FROM DR2_User_R2.dbo.TB_UserItem_Enchant
GO

INSERT dbo.TB_UserItem_MonsterCard SELECT * FROM DR2_User_R2.dbo.TB_UserItem_MonsterCard
GO

INSERT dbo.TB_UserItem_UnbindDate SELECT * FROM DR2_User_R2.dbo.TB_UserItem_UnbindDate
GO
---------------- END TB_UserItem ���̺� ó��




/********************************3.������ ������ ���� ����*********************************/