USE DR2_Member_S1
GO

/* =============================
	STEP 1 : �׳� ��ġ�� �Ǵ� ���̺�
================================ */
INSERT dbo.Member SELECT * FROM DR2_Member_S2.dbo.Member
GO

-- IDX
INSERT INTO [dbo].[TB_DefGMAccountLinkIP]
	([ID] ,[IP] ,[SubNetMask] ,[GMLevel] ,[Memo])
     SELECT [ID] ,[IP] ,[SubNetMask] ,[GMLevel] ,[Memo] FROM [DR2_Member_S2].[dbo].[TB_DefGMAccountLinkIP]
GO

INSERT dbo.TB_MemberSub SELECT * FROM DR2_Member_S2.dbo.TB_MemberSub
GO

-- IDX
INSERT INTO [dbo].[tbl_CashLog]
	([MemberKey],[CharacterID],[f_type],[f_status],[f_amount],[f_current],[f_date],[f_memo],[f_usedmileage],[f_newmileage],[f_curmileage],[f_CashCode])
	SELECT [MemberKey],[CharacterID],[f_type],[f_status],[f_amount],[f_current],[f_date],[f_memo],[f_usedmileage],[f_newmileage],[f_curmileage],[f_CashCode]
	FROM [DR2_Member_S2].[dbo].[tbl_CashLog]
GO

-- IDX
INSERT INTO [dbo].[TB_Event_Coupon]
	([f_CouponID],[f_EventKey],[f_RewardKey],[f_OwnerMemberGuid],[f_OwnerCharacterGuid]
	,[f_TakerMemberGuid],[f_TakerCharacterGuid],[f_CreateDate],[f_TakeDate],[f_RewardGuid1]
	,[f_RewardGuid2],[f_RewardGuid3],[f_RewardGuid4],[f_Site],[f_Realm])
     SELECT [f_CouponID],[f_EventKey],[f_RewardKey],[f_OwnerMemberGuid],[f_OwnerCharacterGuid]
	,[f_TakerMemberGuid],[f_TakerCharacterGuid],[f_CreateDate],[f_TakeDate],[f_RewardGuid1]
	,[f_RewardGuid2],[f_RewardGuid3],[f_RewardGuid4],[f_Site],[f_Realm]
	FROM [DR2_Member_S2].[dbo].[TB_Event_Coupon]

/* =============================
	�׳� ������ �ξ�� �� ���̺�
================================ */
-- dbo.TB_BattleSquare_Game
-- dbo.TB_BattleSquare_MonRegen
-- dbo.TB_BattleSquare_Reward
-- dbo.TB_BattleSquare_Status

-- dbo.TB_EventQuest
-- dbo.TB_EventQuest_Notice
-- dbo.TB_EventQuest_Reward
-- dbo.TB_EventQuest_Status
-- dbo.TB_EventQuest_Target

-- dbo.tbl_CashType
-- dbo.TB_EventQuest_CompleteStatus

-- dbo.TB_Event_Reward
-- dbo.TB_Event_Type
-- dbo.TB_Event_Type_Reward

-- TB_AdminCmd

/* =============================
	�������� ���̺� �Ǵ� �븸 Ȯ�� �ʿ�
================================ */

/* =============================
	��Ȯ�� ���̺�
================================ */
