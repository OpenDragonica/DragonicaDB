USE DR2_User_R1
GO

/*	/////////////////////////////////////////////////////////
 	STEP 1.  : ������� �ʴ� ���̺� ����
///////////////////////////////////////////////////////// */
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TB_BlockCharacter]') AND type in (N'U'))
	DROP TABLE [dbo].[TB_BlockCharacter]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TB_CharacterBasic_TJ]') AND type in (N'U'))
	DROP TABLE [dbo].[TB_CharacterBasic_TJ]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TB_Guild_Basic_Info_TJ]') AND type in (N'U'))
	DROP TABLE [dbo].[TB_Guild_Basic_Info_TJ]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TB_UserCharacter]') AND type in (N'U'))
	DROP TABLE [dbo].[TB_UserCharacter]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TB_RemoveCharacter]') AND type in (N'U'))
	DROP TABLE [dbo].[TB_RemoveCharacter]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TB_Ring_CopyUser]') AND type in (N'U'))
	DROP TABLE [dbo].[TB_Ring_CopyUser]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TB_Ring_Ready2Delete]') AND type in (N'U'))
	DROP TABLE [dbo].[TB_RemoveCharacter]
GO


/*	/////////////////////////////////////////////////////////
 	STEP 2. : �ӽ÷� ������ ���̺� ����
///////////////////////////////////////////////////////// */
-- Guild ����
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TB_Guild_Basic_Info_R2]') AND type in (N'U'))
	DROP TABLE [dbo].[TB_Guild_Basic_Info_R2]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TB_Guild_Basic_Info_R2_Dupl]') AND type in (N'U'))
	DROP TABLE [dbo].[TB_Guild_Basic_Info_R2_Dupl]
GO

-- Character ����
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TB_CharacterBasic_R2]') AND type in (N'U'))
	DROP TABLE [dbo].[TB_CharacterBasic_R2]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TB_CharacterBasic_R2_Dupl]') AND type in (N'U'))
	DROP TABLE [dbo].[TB_CharacterBasic_R2_Dupl]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TempGuildMember]') AND type in (N'U'))
	DROP TABLE [dbo].[TempGuildMember]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TempRankTable]') AND type in (N'U'))
	DROP TABLE [dbo].[TempRankTable]
GO


-- Emporia ����
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup_TB_Emporia]') AND type in (N'U'))
	DROP TABLE [dbo].[Backup_TB_Emporia]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup_TB_Emporia_ChallengeBattle]') AND type in (N'U'))
	DROP TABLE [dbo].[Backup_TB_Emporia_ChallengeBattle]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup_TB_Emporia_Function]') AND type in (N'U'))
	DROP TABLE [dbo].[Backup_TB_Emporia_Function]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Backup_TB_Emporia_Tournament]') AND type in (N'U'))
	DROP TABLE [dbo].[Backup_TB_Emporia_Tournament]
GO

